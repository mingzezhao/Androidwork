package com.bytedance.practice5;

public class Constants {
    public static final String BASE_URL = "https://api-sjtu-camp-2021.bytedance.com/homework/invoke/";
    public static final String token = "U0pUVS1ieXRlZGFuY2UtYW5kcm9pZA==";
    //TODO 1这里写上自己的学号和名字
    public static final String STUDENT_ID = "517020910069";
    public static final String USER_NAME = "赵明泽";

}
